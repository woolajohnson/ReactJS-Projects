import React from "react";
import MyPet from "./components/MyPet";

const App = () => {
    return (
        <>
            <MyPet />
        </>
    );
};

export default App;
