import React from "react";
import PollSurvey from "./components/PollSurvey";

const App = () => {
    return (
        <>
            <PollSurvey />
        </>
    );
};

export default App;
