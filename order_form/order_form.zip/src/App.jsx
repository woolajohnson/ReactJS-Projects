import React from "react";
import OrderForm from "./components/OrderForm";

function App() {
    return (
        <>
            <OrderForm />
        </>
    );
}

export default App;
