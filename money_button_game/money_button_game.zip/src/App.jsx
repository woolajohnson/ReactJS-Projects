import React from "react";
import MoneyButtonGame from "./assets/components/MoneyButtonGame";

const App = () => {
    return (
        <div>
            <MoneyButtonGame />
        </div>
    );
};

export default App;
