import React from "react";
import Contact from "./components/Contact";
import "./assets/stylesheets/Style.css";

function App() {
    return (
        <>
            <Contact />
        </>
    );
}

export default App;
