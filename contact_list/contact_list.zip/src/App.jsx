import React from "react";
import Contact from "./Contact";
import "./assets/stylesheets/Style.css";

function App() {
    return (
        <>
            <Contact />
        </>
    );
}

export default App;
