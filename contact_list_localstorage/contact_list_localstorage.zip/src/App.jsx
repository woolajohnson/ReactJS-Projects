import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import ContactList from "./components/ContactList";

const App = () => {
    return (
        <>
            <ContactList />
        </>
    );
};

export default App;
