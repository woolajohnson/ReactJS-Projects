import React from "react";
import ToggleSwitch from "./components/ToggleSwitch";

function App() {
    return (
        <>
            <ToggleSwitch />
        </>
    );
}

export default App;
