import React from "react";
import Reaction from "./components/Reaction";

const App = () => {
    return (
        <>
            <Reaction />
        </>
    );
};

export default App;
