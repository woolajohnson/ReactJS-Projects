import React from "react";
import Click from "./Click";
import "./assets/stylesheets/Style.css";

function App() {
    return (
        <>
            <Click />
        </>
    );
}

export default App;
